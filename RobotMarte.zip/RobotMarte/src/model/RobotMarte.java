
package model;

import java.io.Serializable;

public class RobotMarte implements CSVConvertible, Comparable<RobotMarte>, Serializable{
      private int id;
    private String nombre;
    private TipoRobot tipo;
    private int nivelBateria;
    private int anioFabricacion;
    private double kmRecorridos;

    public RobotMarte(int id, String nombre, TipoRobot tipo, int nivelBateria, int anioFabricacion, double kmRecorridos) {
        this.id = id;
        this.nombre = nombre;
        this.tipo = tipo;
        this.nivelBateria = nivelBateria;
        this.anioFabricacion = anioFabricacion;
        this.kmRecorridos = kmRecorridos;
    }

    public String getNombre() {
        return nombre;
    }

    public TipoRobot getTipo() {
        return tipo;
    }

    @Override
    public String toCSV() {
       return id + "," + nombre + "," + tipo + "," + nivelBateria + "," + anioFabricacion + "," + kmRecorridos;
        
    }

    @Override
    public int compareTo(RobotMarte r) {
        if (this.nivelBateria != r.nivelBateria) {
            return Integer.compare(r.nivelBateria, this.nivelBateria);
        }
        return Double.compare(r.kmRecorridos, this.kmRecorridos);
    }
    
    
      @Override
    public String toString() {
        return "RobotMarte{id=" + id + ", nombre='" + nombre + '\'' +
               ", tipo=" + tipo + ", nivelBateria=" + nivelBateria +
               ", anioFabricacion=" + anioFabricacion + ", kmRecorridos=" + kmRecorridos + '}';
    }

    @Override
    public String toHeaderCSV() {
         return "id,nombre,tipo,nivelBateria,anioFabricacion,kmRecorridos";
    }
    
    
    
    
}
