
package model;


public interface CSVConvertible {
    String toCSV();
    String toHeaderCSV();
}
