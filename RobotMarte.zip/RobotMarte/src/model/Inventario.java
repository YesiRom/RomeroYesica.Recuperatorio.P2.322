package model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import model.Almacenable;
import model.CSVConvertible;



public class Inventario<T extends  CSVConvertible> implements Almacenable<T> {
    
     List<T> robots = new ArrayList<>();
     
     private void validarIngreso(T ingreso) {
        if (ingreso == null) {
            throw new NullPointerException("ingreso nulo");
        }
    }

    @Override
    public void agregar(T elemento) {
         validarIngreso(elemento);
        robots.add(elemento);
    }

    @Override
    public void eliminarSegun(Predicate<T> criterio) {
        List<T> toRemove = new ArrayList<>();
        for (T t : robots) {
            if (criterio.test(t)) toRemove.add(t);
        }
        robots.removeAll(toRemove);
    }

    @Override
    public List<T> obtenerTodos() {
         return new ArrayList<>(robots);
    }

    @Override
    public T buscar(Predicate<T> criterio) {
       for (T t : robots) {
            if (criterio.test(t)) return t;
        }
        return null;
    }

    @Override
    public void ordenar() {
        robots.sort((Comparator<? super T>) Comparator.naturalOrder());
    }

    @Override
    public void ordenar(Comparator<T> comparador) {
          robots.sort(comparador);
    }

    @Override
    public List<T> filtrar(Predicate<T> criterio) {
        List<T> filtrada = new ArrayList<>();
        for (T item : robots) {
            if (criterio.test(item)) {
                filtrada.add(item);
            }
        }
        return filtrada;
    }

    @Override
    public List<T> transformar(Function<T, T> operador) {
       List<T> toReturn = new ArrayList<>();
    for (T item : this) {
        toReturn.add(operador.apply(item));
    }
    return toReturn;
    }

    @Override
    public int contar(Predicate<T> criterio) {
       int c = 0;
        for (T t : robots) {
            if (criterio.test(t)) c++;
        }
        return c;
    }

    
    @Override
    public void guardarEnBinario(String ruta) throws Exception {
         try (ObjectOutputStream serializador = new ObjectOutputStream(new FileOutputStream(ruta))) {
            serializador.writeObject(robots);
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public void cargarDesdeBinario(String ruta) throws Exception {
      robots.clear();
        try (ObjectInputStream desearializador = new ObjectInputStream(new FileInputStream(ruta))) {
            robots = (List<T>) desearializador.readObject();
        } catch (IOException | ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public void guardarEnCSV(String ruta) throws Exception {
         if (robots.isEmpty()) return;

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ruta))) {
            // Escribo el header a partir del primer elemento
            bw.write(robots.get(0).toHeaderCSV());
            bw.newLine();

            for (T elem : robots) {
                bw.write(elem.toCSV());
                bw.newLine();
            }
        }
    }

        @Override
        public void cargarDesdeCSV(String ruta, Function<String, T> fromCSV) throws Exception {
             File archivo = new File(ruta);

    try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
        limpiar();
        String linea;
        br.readLine();
        while ((linea = br.readLine()) != null) {
            T elem = (T) lector.desdeLinea(linea); 
            agregar(elem);
        }
    } catch (IOException e) {
        System.out.println(e.getMessage());
    }
        }

     @Override
       public void limpiar() {
        robots.clear();
     }
        

        @Override
        public void guardarEnJSON(String ruta) throws Exception {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

    @Override
    public Iterator<T> iterator() {
       if (!robots.isEmpty() && robots.get(0) instanceof Comparable) { 
        return iterator((Comparator<? super T>) Comparator.naturalOrder());
    }
    return robots.iterator();
    }
    
    public Iterator<T> iterator(Comparator<? super T> comparador) {
    List<T> copia = new ArrayList<>(robots);
    copia.sort(comparador);
    return copia.iterator();
}

      
    
}
